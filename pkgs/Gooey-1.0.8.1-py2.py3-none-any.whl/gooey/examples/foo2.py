import foo

def main():
  foo.initOptParser()

if __name__ == '__main__':
  main()
