# '''
# Delegates arguments to the main Gooey runner
#
# For use when run directly from command line with the -m (module) flag:
#
#   e.g. $ python -m gooey
#
# '''
#
# from gooey import application
#
# application.main()
