"""
Configuration settings for the program.
More or less, this is just used so that the i18n module
can load the right language file at runtime.
"""

LANG = 'english'
