from gooey.gui.components.widgets.textfield import TextField



__ALL__ = ('CommandField',)

class CommandField(TextField):
    pass
