from ._svg import write

__all__ = ["write"]
