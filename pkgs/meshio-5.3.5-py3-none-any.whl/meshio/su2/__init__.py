from ._su2 import read, write

__all__ = ["read", "write"]
